﻿namespace Ecomerce.Models
{
    public class Product
    {
        public int Id { get; set; }
        public required string Name { get; set; }
        public string? Description { get; set; }
        public decimal Price { get; set; }
        public int Amount { get; set; }
        public int CategoryId { get; set; }
        public virtual Category? category { get; set; }
        public virtual List<Order>? Orders { get; set; }
    }
}