﻿using Ecomerce.Models;
using Microsoft.EntityFrameworkCore;

namespace Ecomerce.DatabaseConnection
{
    public class AppDbcontext : DbContext
    {
        public AppDbcontext(DbContextOptions<AppDbcontext> options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<CustomerProfile> CustomerProfiles { get; set; }
        public DbSet<Order> Orders { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>()
                .HasMany(c => c.products)
                .WithOne(p => p.category)
                .HasForeignKey(p => p.CategoryId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Customer>()
                .HasOne(c => c.CustomerProfile)
                .WithOne(p => p.Customer)
                .HasForeignKey<CustomerProfile>(p => p.CustomerId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Customer>().HasMany(c => c.Orders)
                .WithOne(o => o.Customer)
                .HasForeignKey(o => o.CustomerId)
                .OnDelete(DeleteBehavior.Cascade);
            modelBuilder.Entity<Customer>().Property(n => n.Name).HasMaxLength(100);
            modelBuilder.Entity<Customer>().HasData(
                new Customer
                {
                    Id = 1,
                    Name = "maro",
                    Email = "maro@gmail.com",
                    Password = "password",
                },
                new Customer
                {
                    Id = 1002,
                    Name = "John Doe", // Add other required fields
                    Email = "john@example.com",
                    Password = "password",
                }
                );
            modelBuilder.Entity<Order>().HasData(
    new Order
    {
        Id = 1,
        orderId = Guid.Parse("a1b2c3d4-e5f6-7890-abcd-1234567890ab"),
        TotalPrice = 5000,
        OrderDate = new DateTime(2025, 10, 12),
        CustomerId = 1002
    }
);


        }
    }
}
