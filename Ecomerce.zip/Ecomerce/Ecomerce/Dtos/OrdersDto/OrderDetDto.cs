﻿using System.ComponentModel.DataAnnotations.Schema;
using Ecomerce.Dtos.ProductDto;
using Ecomerce.Models;

namespace Ecomerce.Dtos.OrdersDto
{
    public class OrderDetDto
    {
        
        public Guid orderId { get; set; }
        [Column(TypeName = "decimal(19,5)")]
        public decimal TotalPrice { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.Now.AddDays(14);
        public string Name { get; set; }
        public string Email { get; set; }
        public List<ProductDetDto>? products { get; set; }
    }
}
