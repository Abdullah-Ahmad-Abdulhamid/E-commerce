﻿namespace Ecomerce.Dtos
{
    public class CustomerDetDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
