﻿using System.ComponentModel.DataAnnotations;

namespace Ecomerce.Dtos
{
    public class CustomerGDto
    {
        
        public string Name { get; set; }

        
        public string Email { get; set; }
        public List<OrderDto> orders { get; set; }
    }
}
