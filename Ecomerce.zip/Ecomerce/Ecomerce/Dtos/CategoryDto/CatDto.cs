﻿namespace Ecomerce.Dtos.CategoryDto
{
    public class CatDto
    {
        public string Name {  get; set; }

    }
}
