﻿using Ecomerce.Dtos.CategoryDto;
namespace Ecomerce.Dtos.ProductDto
{
    public class ProductCatDto
    {
        public required string Name { get; set; }
        public decimal Price { get; set; }
        public int Amount { get; set; }
        public CatDto? CategoryDto  { get; set; }
    }
}
