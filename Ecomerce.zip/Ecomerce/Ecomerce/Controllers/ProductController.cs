﻿using Ecomerce.Dtos.ProductDto;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Ecomerce.Models;
using Ecomerce.DatabaseConnection;
using Microsoft.EntityFrameworkCore;
namespace Ecomerce.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly AppDbcontext db;

        public ProductController(AppDbcontext db)
        {
            this.db = db;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var row = await db.Products.Include(x => x.category).Select(x => new ProductCatDto { Name = x.Name, Amount = x.Amount,Price = x.Price,CategoryDto = new Dtos.CategoryDto.CatDto { Name = x.Name} }).ToListAsync();
            if(row == null) return NotFound("product is not found");
            
            return Ok(row);
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var product = await db.Products.Include(x => x.category).FirstOrDefaultAsync(x => x.Id == id);
            if (product == null) return NotFound();
            var products = new ProductCatDto { Name = product.Name, Amount = product.Amount, Price = product.Price, CategoryDto = new Dtos.CategoryDto.CatDto { Name = product.Name } };
            return Ok(products);
        }
        //[HttpPost]
        //public async Task<IActionResult> post(ProductAddDto productAddDto)
        //{
        //    var p = new Product
        //    {
        //        Name = productAddDto.Name,
        //        Amount = productAddDto.Amount,
        //        Price = productAddDto.Price,
        //        CategoryId = productAddDto.categoroyId,
        //        Description = productAddDto.Description,
        //    };
        //    await 
        //}
    }
}
