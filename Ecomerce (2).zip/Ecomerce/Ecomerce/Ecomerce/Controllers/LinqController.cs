﻿using Ecomerce.DatabaseConnection;
using Ecomerce.Dtos.ProductDto;
using Ecomerce.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Ecomerce.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LinqController : ControllerBase
    {
        readonly AppDbcontext dbcontext;

        public LinqController(AppDbcontext dbcontext)
        {
            this.dbcontext = dbcontext;
        }
        [HttpGet("above100")]
        public IActionResult Q1() { var orders = dbcontext.Orders.Where(x => x.TotalPrice > 100).ToList(); return Ok(orders); }
        [HttpGet("outofstock")]
        public IActionResult Q2() { var prod = dbcontext.Products.Where(x => x.stock ==0).Select( x=> new ProductCatDto { Name = x.Name}).ToList(); return Ok(prod); }
        [HttpGet("Placedtoday")]
        public IActionResult Q3() { var prod = dbcontext.Orders.Where(x => x.OrderDate == DateTime.Today).ToList(); return Ok(prod); }  
        [HttpGet("customersEmail")]
        public IActionResult Q4() { var prod = dbcontext.Customers.Select(x => x.Email).ToList(); return Ok(prod); }      
        [HttpGet("CustomersProduct")]
        public IActionResult Q5() { var prod = dbcontext.Orders.Include(x => x.Products).SelectMany(x => x.Products).ToList(); return Ok(prod); }
          [HttpGet("ProductName")]
        public IActionResult Q6() { var prod = dbcontext.Orders.Include(x => x.Products).SelectMany(x => x.Products).Select(x=>x.Name).ToList(); return Ok(prod); }
        [HttpGet("morethan2")]
        public IActionResult Q7() { var prod = dbcontext.Orders.Include(x => x.Products).Where(x => x.Products.Count() >= 2).Select(x => new
        {
            id = x.Id,
            products = x.Products.Select(x => x.Name)
        }).ToList(); return Ok(prod); }      
        [HttpGet("morethan100")]
        public IActionResult Q8() { var prod = dbcontext.Orders.Include(x => x.Products).Select(x=> new 
        {
            id = x.Id,
            OrderDate = x.OrderDate,
            products = x.Products.Where(x => x.Price > 100).Select(x=> new
            {
                id = x.Id,
                price = x.Price

            }).ToList()

        }).ToList(); return Ok(prod); }       
        [HttpGet("morethan100and more than 2")]
        public IActionResult Q9() { var prod = dbcontext.Orders.Include(x => x.Products).Where(x=>x.Products.Count()>=2).Select(x=> new 
        {
            id = x.Id,
            OrderDate = x.OrderDate,
            products = x.Products.Where(x => x.Price > 100).Select(x=> new
            {
                id = x.Id,
                price = x.Price,
                Name = x.Name
                

            }).ToList()

        }).ToList(); return Ok(prod); }

    }
}
