﻿using Ecomerce.DatabaseConnection;
using Ecomerce.Dtos;
using Ecomerce.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Ecomerce.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly AppDbcontext dbcontext;

        public CustomerController(AppDbcontext dbcontext)
        {
            this.dbcontext = dbcontext;
        }

        [HttpGet]
        public async Task<IActionResult> List()
        {
            var customers = await dbcontext.Customers
                .Select(x => new CustomerDetDto { Name = x.Name,Email=x.Email})
                .ToListAsync();
            if (customers == null || customers.Count == 0)
                return NotFound("No customers found.");
            
            return Ok(customers);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var customer = await dbcontext.Customers.FirstOrDefaultAsync(x => x.Id == id);
            if (customer == null)
                return NotFound($"Customer with ID {id} not found.");
            var cus = new CustomerGDto
            {
                Name = customer.Name,
                Email = customer.Email,
                orders = customer.Orders.Select(o => new OrderDto { OrderDate = o.OrderDate,
                TotalPrice = o.TotalPrice}).ToList()
            };
            return Ok(cus);
        }

        [HttpGet("getName/{name}")]
        public async Task<IActionResult> GetByName(string name)
        {
            var customer = await dbcontext.Customers.FirstOrDefaultAsync(x => x.Name == name);
            if (customer == null)
                return NotFound($"Customer with name '{name}' not found.");
            return Ok(customer);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var customer = await dbcontext.Customers.FirstOrDefaultAsync(x => x.Id == id);
            if (customer == null)
                return NotFound("Customer not found.");
            dbcontext.Customers.Remove(customer);
            await dbcontext.SaveChangesAsync();
            return NoContent();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Edit(int id, [FromBody] CustomerDto dto)
        {

            var customer = await dbcontext.Customers.FirstOrDefaultAsync(x => x.Id == id);
            if (customer == null)
                return NotFound("Customer not found.");

            customer.Name = dto.Name;
            customer.Email = dto.Email;
            customer.Password = dto.Password;

            dbcontext.Customers.Update(customer);
            await dbcontext.SaveChangesAsync();
            return NoContent();
        }

        [HttpPost]
        public async Task<IActionResult> Add([FromBody] CustomerDto dto)
        {
            

            var customer = new Customer
            {
                Name = dto.Name,
                Email = dto.Email,
                Password = dto.Password
            };

            dbcontext.Customers.Add(customer);
            await dbcontext.SaveChangesAsync();
            return CreatedAtAction("GetById",new {id = customer.Id},customer);
        }
    }
}
