﻿using Ecomerce.DatabaseConnection;
using Ecomerce.Dtos;
using Ecomerce.Dtos.OrdersDto;
using Ecomerce.Dtos.ProductDto;
using Ecomerce.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Ecomerce.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly AppDbcontext db;

        public OrdersController(AppDbcontext db)
        {
            this.db = db;
        }
        [HttpGet]
        public async Task<IActionResult> List()
        {
            var order = await db.Orders.Select(x => new OrderDto { OrderDate = x.OrderDate,
                TotalPrice = x.TotalPrice }).ToListAsync();
            if(order == null ) return NotFound("not orders found");
            return Ok(order);
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var order = await db.Orders.Include(c => c.Customer).Include(p => p.Products).FirstOrDefaultAsync(x => x.Id == id);
            var Product =order.Products.Select(x => new ProductDetDto { Name = x.Name, Amount = x.Amount, Price = x.Price }).ToList();
            var orders = new OrderDetDto
            {
                OrderDate = order.OrderDate,
                TotalPrice = order.TotalPrice,
                Name = order.Customer.Name,
                Email = order.Customer.Email,
                products = Product
            };
            if(order == null) return NotFound("not found order");
            return Ok(orders);
        }
        [HttpPost]
        public async Task<IActionResult> Add(OrderAddDto orderDto)
        {
            var order = new Order
            {
                OrderDate = orderDto.OrderDate,
                TotalPrice= orderDto.TotalPrice,
                CustomerId = orderDto.customerId,
            };
            await db.Orders.AddAsync(order);
            await db.SaveChangesAsync();
            return CreatedAtAction("Get",new {id = order.Id},order);

        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var order = await db.Orders.FirstOrDefaultAsync(x => x.Id == id);
            if (order == null) return NotFound("not found order");
            return NoContent();
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Edit(int id ,[FromBody] OrderAddDto orderDto)
        {
            var order = await db.Orders.FirstOrDefaultAsync(x => x.Id == id);
            if (order == null) return NotFound("order not found");
            order.OrderDate = orderDto.OrderDate;
            order.TotalPrice = orderDto.TotalPrice;
            order.CustomerId = orderDto.customerId;
            db.Orders.Update(order);
            await db.SaveChangesAsync();
            return NoContent();
        }
    }
}
