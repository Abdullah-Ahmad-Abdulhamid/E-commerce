﻿using Ecomerce.DatabaseConnection;
using Ecomerce.Dtos;
using Ecomerce.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Ecomerce.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerOrderController : ControllerBase
    {
        private readonly AppDbcontext db;

        public CustomerOrderController(AppDbcontext db)
        {
            this.db = db;
        }

        [HttpGet("{id}")]
        public ActionResult Get(int id)
        {
            var obj =  db.Customers.Include(c => c.Orders).FirstOrDefault(c => c.Id == id);
            return Ok(obj);
        }
        [HttpGet("Explicit/{id}")]
        public ActionResult GetExplict(int id)
        {
            var obj = db.Customers.FirstOrDefault(c => c.Id == id);
            db.Entry(obj).Collection(o => o.Orders).Load();
            return Ok(obj);
        }
        [HttpGet("lazy/{id}")]
        public ActionResult Getlazy(int id)
        {
            var obj = db.Customers.FirstOrDefault(c => c.Id == id);
            var cus = new CustomerDto
            {
                Password = obj.Password,
                Email = obj.Email,
                Name = obj.Name,
                orders = obj.Orders.Select(o => new OrderDto
                {
                    OrderDate = o.OrderDate,
                    TotalPrice = o.TotalPrice
                }).ToList()
            };
          
            return Ok(obj);
        }
    }
}
