﻿using System.Text.Json.Serialization;

namespace Ecomerce.Models
{
    public class Product
    {
        public int Id { get; set; }
        public required string Name { get; set; }
        public string? Description { get; set; }
        public decimal Price { get; set; }
        public int Amount { get; set; }
        public int CategoryId { get; set; }
        public int stock {  get; set; }
        [JsonIgnore]
        public virtual Category? category { get; set; }
        [JsonIgnore]
        public virtual List<Order>? Orders { get; set; }
    }
}