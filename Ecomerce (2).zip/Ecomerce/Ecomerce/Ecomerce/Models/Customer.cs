﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace Ecomerce.Models
{
    [Index(nameof(Email), IsUnique = true)]
    public class Customer
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        
        [Required]
        public  string Email { get; set; }
        [Range(7,20)]
        [Required]
        public string Password { get; set; }
        public virtual CustomerProfile? CustomerProfile { get; set; }
        public virtual List<Order>? Orders { get; set; }
    }
}
