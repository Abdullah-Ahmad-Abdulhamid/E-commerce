﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Ecomerce.Models
{
    public class Order
    {
        public int Id { get; set; }
        public decimal TotalPrice { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.Now.AddDays(14);
        public virtual List<Product>? Products { get; set; }
        public int CustomerId { get; set; }
        [JsonIgnore]
        public virtual Customer? Customer { get; set; }
    }
}
