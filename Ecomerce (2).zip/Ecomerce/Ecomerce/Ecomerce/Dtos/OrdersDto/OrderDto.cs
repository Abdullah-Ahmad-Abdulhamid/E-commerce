﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Ecomerce.Dtos
{
    public class OrderDto
    {
        [Column(TypeName = "decimal(19,5)")]
        public decimal TotalPrice { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.Now.AddDays(14);
    }
}
