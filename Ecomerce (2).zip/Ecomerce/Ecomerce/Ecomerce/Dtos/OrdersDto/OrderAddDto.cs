﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Ecomerce.Dtos.OrdersDto
{
    public class OrderAddDto
    {
        [Column(TypeName = "decimal(19,5)")]
        public decimal TotalPrice { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.Now.AddDays(14);
        public int customerId { get; set; }
    }
}
