﻿using System.ComponentModel.DataAnnotations;
using Ecomerce.Models;

namespace Ecomerce.Dtos
{
    public class CustomerDto
    {
        [Required]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [StringLength(20, MinimumLength = 7, ErrorMessage = "The field Password must be between 7 and 20.")]
        public string Password { get; set; }
        public List<OrderDto> orders { get; set; }
    }
}
