﻿using Ecomerce.Models;

namespace Ecomerce.Dtos.ProductDto
{
    public class ProductDetDto
    {
        public required string Name { get; set; }
        public decimal Price { get; set; }
        public int Amount { get; set; }
        public int CategoryId { get; set; }
        
    }
}
