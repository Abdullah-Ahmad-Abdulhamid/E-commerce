﻿using Ecomerce.Models;
using Microsoft.EntityFrameworkCore;

namespace Ecomerce.DatabaseConnection
{
    public class AppDbcontext : DbContext
    {
        public AppDbcontext(DbContextOptions<AppDbcontext> options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<CustomerProfile> CustomerProfiles { get; set; }
        public DbSet<Order> Orders { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Category-Product relation
            modelBuilder.Entity<Category>()
                .HasMany(c => c.products)
                .WithOne(p => p.category)
                .HasForeignKey(p => p.CategoryId)
                .OnDelete(DeleteBehavior.Cascade);

            // Customer-CustomerProfile relation
            modelBuilder.Entity<Customer>()
                .HasOne(c => c.CustomerProfile)
                .WithOne(p => p.Customer)
                .HasForeignKey<CustomerProfile>(p => p.CustomerId)
                .OnDelete(DeleteBehavior.Cascade);

            // Customer-Order relation
            modelBuilder.Entity<Customer>()
                .HasMany(c => c.Orders)
                .WithOne(o => o.Customer)
                .HasForeignKey(o => o.CustomerId)
                .OnDelete(DeleteBehavior.Cascade);

            // Constraints
            modelBuilder.Entity<Customer>().Property(n => n.Name).HasMaxLength(100);

            // ---------------- Seeding ----------------

            // Categories
            modelBuilder.Entity<Category>().HasData(
                new Category { Id = 1, Name = "Electronics", Description = "Electronic Devices" },
                new Category { Id = 2, Name = "Clothing", Description = "Men and Women Clothing" },
                new Category { Id = 3, Name = "Books", Description = "All kinds of Books" }
            );

            // Products
            modelBuilder.Entity<Product>().HasData(
                new Product { Id = 1, Name = "Laptop", Description = "Dell XPS 13", Price = 1500, Amount = 10, stock = 10, CategoryId = 1 },
                new Product { Id = 2, Name = "Smartphone", Description = "Samsung Galaxy S24", Price = 1000, Amount = 20, stock = 20, CategoryId = 1 },
                new Product { Id = 3, Name = "T-shirt", Description = "Cotton T-shirt", Price = 20, Amount = 50, stock = 50, CategoryId = 2 },
                new Product { Id = 4, Name = "Novel", Description = "The Alchemist", Price = 15, Amount = 30, stock = 30, CategoryId = 3 }
            );

            // Customers
            modelBuilder.Entity<Customer>().HasData(
                new Customer
                {
                    Id = 1,
                    Name = "maro",
                    Email = "maro@gmail.com",
                    Password = "password"
                },
                new Customer
                {
                    Id = 1002,
                    Name = "John Doe",
                    Email = "john@example.com",
                    Password = "password"
                }
            );

            // Orders
            modelBuilder.Entity<Order>().HasData(
                new Order { Id = 1, TotalPrice = 5000, OrderDate = new DateTime(2025, 10, 12), CustomerId = 1002},
                new Order { Id = 2, TotalPrice = 6000, OrderDate = new DateTime(2025, 10, 12), CustomerId = 1 },
                new Order { Id = 3, TotalPrice = 50, OrderDate = new DateTime(2025, 11, 12), CustomerId = 1 }
            );
        }
    }
}
